module.exports = [
	{path: "/", method: "get", handler: "./api/home.js"}
];