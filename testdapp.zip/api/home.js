module.exports = function (query, cb) {
	cb(null, {
		test: "Hello, world!"
	});
}